package com.model;

public class DatabaseDetails {
	
	private String host;
    private String port;
    private String service;
    private String url;
    private String password;
	public String getHost() {
		return host;
	}
	public void setHost(String host) {
		this.host = host;
	}
	public String getPort() {
		return port;
	}
	public void setPort(String port) {
		this.port = port;
	}
	public String getService() {
		return service;
	}
	public void setService(String service) {
		this.service = service;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "DatabaseDetails [host=" + host + ", port=" + port + ", service=" + service + ", url=" + url
				+ ", password=" + password + "]";
	}
    

}
